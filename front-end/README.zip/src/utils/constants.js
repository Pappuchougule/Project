export const constants = {
    serverUrl: 'http://localhost:5090/',
}

export const constant = {
    serverUrl: 'http://localhost:9999/',
}